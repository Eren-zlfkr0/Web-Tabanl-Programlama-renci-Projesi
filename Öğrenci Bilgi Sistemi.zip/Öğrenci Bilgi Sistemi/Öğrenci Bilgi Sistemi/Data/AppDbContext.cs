﻿using Microsoft.EntityFrameworkCore;
using Öğrenci_Bilgi_Sistemi;
using Öğrenci_Bilgi_Sistemi.Models;

namespace Öğrenci_Bilgi_Sistemi.Data
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) 
            : base(options) { }
        public DbSet<Student> Students { get; set; }
    }
}
